This is a simple tree data structure implementation in python.


