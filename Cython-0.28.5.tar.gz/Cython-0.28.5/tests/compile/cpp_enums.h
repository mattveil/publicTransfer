enum Enum1 {
  Item1,
  Item2
};

namespace Namespace1 {
  enum Enum2 {
    Item3,
    Item4
  };
}
