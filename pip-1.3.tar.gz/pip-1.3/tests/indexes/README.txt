
Details on Test Indexes
=======================

empty_with_pkg
--------------
empty index, but there's a package in the dir

in dex
------
for testing url quoting with indexes

simple
------
contains index page for "simple" pkg
