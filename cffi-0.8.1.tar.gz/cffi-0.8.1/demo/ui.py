#!/usr/bin/env python

import os
import curses

os.chdir('/home/arigo/Music/x/')
execfile('ui.py')
